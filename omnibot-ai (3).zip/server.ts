import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import axios from "axios";
import dotenv from "dotenv";

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '50mb' }));

  // Ollama Proxy Endpoint
  // This helps avoid CORS issues when calling a local Ollama instance from the browser
  app.post("/api/ollama/chat", async (req, res) => {
    try {
      const { model, messages, stream } = req.body;
      const ollamaUrl = process.env.OLLAMA_URL || "http://localhost:11434";
      
      const response = await axios.post(`${ollamaUrl}/api/chat`, {
        model: model || "llama3",
        messages,
        stream: stream || false
      });

      res.json(response.data);
    } catch (error: any) {
      const ollamaUrl = process.env.OLLAMA_URL || "http://localhost:11434";
      console.error("Ollama Proxy Error:", error.message);
      
      let errorMessage = "Failed to communicate with Ollama.";
      if (error.code === 'ECONNREFUSED') {
        errorMessage = `Ollama connection refused at ${ollamaUrl}. Ensure Ollama is running ('ollama serve') and accessible.`;
      }
      
      res.status(500).json({ 
        error: errorMessage, 
        details: error.message,
        suggestion: "If you are using the cloud preview, please switch to the Gemini provider in App.tsx as local Ollama is not accessible from the cloud."
      });
    }
  });

  // API Health Check
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
