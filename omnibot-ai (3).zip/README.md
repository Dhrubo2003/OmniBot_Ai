# OmniBot: Multi-Modal Local AI Co-Pilot

OmniBot is a high-performance, **Multi-Modal AI Assistant** designed as a reusable React widget. Unlike traditional chatbots, OmniBot acts as a "Co-Pilot" for your web applications, capable of seeing what you see, analyzing specific UI components, and executing actions directly within the host website through advanced **Function Calling**.

---

## 🌟 Why OmniBot? (Uniqueness)

OmniBot stands out by bridging the gap between static LLM chat and active workspace assistance:

- **Visual Context Awareness:** Uses WebRTC and `html-to-image` to provide the AI with real-time visual context of the user's screen.
- **Action-Oriented (Function Calling):** Implements a robust tool-use architecture where the AI can trigger client-side functions (e.g., navigating pages, changing settings, or fetching data).
- **Privacy-First (Local LLM):** Powered by **Ollama**, ensuring that all screen data and conversations stay 100% local on the user's machine.
- **"Circle to Search" Experience:** A custom-built region selection tool that allows users to "freeze" the screen and analyze specific sections with precision.

---

## 🛠️ Technical Features

### 1. Multi-Modal Analysis
- **Continuous Screen Sharing:** Leverages the browser's `getDisplayMedia` API to feed a live video stream into the AI for real-time insights.
- **Section Analysis:** A sophisticated cropping tool that captures the current DOM state, allows for user-defined bounding boxes, and processes the selection for vision-capable LLMs (like Llava).

### 2. Intelligent Tool System (Function Calling)
- Supports a JSON-schema based tool definition system.
- Enables the LLM to autonomously decide when to call a function to help the user.
- Handles complex multi-step tool interactions and error reporting.

### 3. Polished UX/UI
- **Draggable Interface:** Built with `framer-motion` for smooth, physics-based dragging of both the chat window and the floating action button.
- **Keyboard Shortcuts:** Global hotkeys (`Ctrl+D+H`) for instant access.
- **Markdown Support:** Rich text rendering for code snippets, lists, and formatted AI responses.

---

## 🚀 Getting Started (Installation)

### 1. Backend: Ollama Setup
OmniBot requires [Ollama](https://ollama.com/) to be running locally.

1. **Enable CORS (Required):**
   ```bash
   # Mac/Linux
   OLLAMA_ORIGINS="*" ollama serve

   # Windows (PowerShell)
   $env:OLLAMA_ORIGINS="*" ; ollama serve
   ```
2. **Download Models:**
   ```bash
   ollama pull llama3   # For logic and tools
   ollama pull llava    # For vision and screen analysis
   ```

### 2. Frontend: Integration
Install dependencies:
```bash
npm install lucide-react framer-motion react-markdown html-to-image
```

Copy the core files into your project:
- `src/components/OmniBotReusable.tsx`
- `src/lib/providers.ts`
- `src/types/omnibot.ts`

### 3. Usage Example
```tsx
import { OmniBotReusable } from './components/OmniBotReusable';
import { OllamaProvider } from './lib/providers';

const App = () => {
  const provider = new OllamaProvider();
  
  const tools = [{
    name: "alertUser",
    description: "Show an alert to the user",
    parameters: { type: "OBJECT", properties: { msg: { type: "STRING" } } },
    execute: (args) => alert(args.msg)
  }];

  return (
    <OmniBotReusable 
      provider={provider} 
      tools={tools} 
      theme={{ botName: "OmniBot", primaryColor: "#3b82f6" }}
    />
  );
};
```

---

## 🏗️ Architecture
- **Frontend:** React 18+, TypeScript, Tailwind CSS.
- **Animations:** Framer Motion.
- **AI Integration:** Ollama API (Local Inference).
- **Image Processing:** HTML Canvas API & SVG-to-Image serialization.

---

## 📄 License
MIT License - Feel free to use this in your own projects!
