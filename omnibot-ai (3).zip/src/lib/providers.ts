import { OmniBotProvider, OmniBotMessage, OmniBotTool } from "@/src/types/omnibot";

/**
 * Ollama Provider (For local LLMs)
 */
export class OllamaProvider implements OmniBotProvider {
  private baseUrl: string;
  private model: string;
  private visionModel: string;

  constructor(baseUrl: string = "http://localhost:11434", model: string = "llama3", visionModel: string = "llava") {
    this.baseUrl = baseUrl;
    this.model = model;
    this.visionModel = visionModel;
  }

  async chat(history: OmniBotMessage[], message: string, tools?: OmniBotTool[], base64Image?: string): Promise<string> {
    const messages: any[] = history.map(m => ({ 
      role: m.role === 'model' ? 'assistant' : 'user', 
      content: m.text 
    }));

    const currentMessage: any = { role: 'user', content: message };
    
    // If there's an image, we should use the vision model
    let targetModel = this.model;
    if (base64Image) {
      // Remove the data:image/png;base64, prefix for Ollama
      const base64Data = base64Image.split(',')[1] || base64Image;
      currentMessage.images = [base64Data];
      targetModel = this.visionModel;
    }

    messages.push(currentMessage);

    const body: any = {
      model: targetModel,
      messages: messages,
      stream: false
    };

    // Ollama supports tools in newer versions
    if (tools && tools.length > 0) {
      body.tools = tools.map(t => ({
        type: "function",
        function: {
          name: t.name,
          description: t.description,
          parameters: t.parameters
        }
      }));
    }

    try {
      const response = await fetch(`${this.baseUrl}/api/chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });

      if (!response.ok) {
        throw new Error(`Ollama API error: ${response.statusText}`);
      }

      const data = await response.json();
      const responseMessage = data.message;

      // Handle tool calls if Ollama returned any
      if (responseMessage.tool_calls && responseMessage.tool_calls.length > 0) {
        const functionResponses = [];
        for (const call of responseMessage.tool_calls) {
          const tool = tools?.find(t => t.name === call.function.name);
          if (tool) {
            try {
              const res = await tool.execute(call.function.arguments);
              functionResponses.push({
                role: 'tool',
                content: JSON.stringify(res || { status: "success" }),
                name: call.function.name
              });
            } catch (err: any) {
              functionResponses.push({
                role: 'tool',
                content: JSON.stringify({ error: err.message }),
                name: call.function.name
              });
            }
          }
        }

        if (functionResponses.length > 0) {
          // Send the tool results back to Ollama
          const followUpBody = {
            model: targetModel,
            messages: [...messages, responseMessage, ...functionResponses],
            stream: false
          };
          const followUpResponse = await fetch(`${this.baseUrl}/api/chat`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(followUpBody)
          });
          const followUpData = await followUpResponse.json();
          return followUpData.message.content || "Task completed.";
        }
      }

      return responseMessage.content || "Task completed.";
    } catch (error: any) {
      console.error("Ollama Provider Error:", error);
      throw new Error(`Failed to connect to Ollama. Make sure it is running locally and CORS is enabled (OLLAMA_ORIGINS="*" ollama serve). Details: ${error.message}`);
    }
  }

  async analyze(base64Image: string, prompt: string): Promise<string> {
    const base64Data = base64Image.split(',')[1] || base64Image;
    
    try {
      const response = await fetch(`${this.baseUrl}/api/chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: this.visionModel,
          messages: [
            {
              role: 'user',
              content: prompt,
              images: [base64Data]
            }
          ],
          stream: false
        })
      });

      if (!response.ok) {
        throw new Error(`Ollama API error: ${response.statusText}`);
      }

      const data = await response.json();
      return data.message.content;
    } catch (error: any) {
      console.error("Ollama Analyze Error:", error);
      throw new Error(`Failed to analyze image with Ollama. Make sure the vision model ('${this.visionModel}') is pulled. Details: ${error.message}`);
    }
  }
}

/**
 * Backend Ollama Provider (Uses the Express proxy)
 */
export class BackendOllamaProvider implements OmniBotProvider {
  private model: string;

  constructor(model: string = "llama3") {
    this.model = model;
  }

  async chat(history: OmniBotMessage[], message: string, tools?: OmniBotTool[], base64Image?: string): Promise<string> {
    const response = await fetch(`/api/ollama/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: this.model,
        messages: [
          ...history.map(m => ({ role: m.role === 'model' ? 'assistant' : 'user', content: m.text })),
          { role: 'user', content: message }
        ],
        stream: false
      })
    });
    
    if (!response.ok) {
      const errorData = await response.json();
      const errorMsg = errorData.error || "Failed to connect to backend Ollama proxy";
      const suggestion = errorData.suggestion ? `\n\n**Suggestion:** ${errorData.suggestion}` : "";
      throw new Error(`${errorMsg}${suggestion}`);
    }

    const data = await response.json();
    return data.message.content;
  }

  async analyze(base64Image: string, prompt: string): Promise<string> {
    return "Vision analysis via backend proxy not yet implemented. Requires a vision-capable model like Llava.";
  }
}
