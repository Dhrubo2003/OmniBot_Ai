import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence, useDragControls } from 'motion/react';
import { Bot, X, Send, Maximize2, Minimize2, Camera, GripVertical, Sparkles, MonitorUp, MonitorOff, Crop, Loader2 } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";
import { OmniBotProps, OmniBotMessage } from "@/src/types/omnibot";
import ReactMarkdown from 'react-markdown';
import * as htmlToImage from 'html-to-image';

/**
 * OmniBotReusable - A standalone, AI-powered widget component.
 */
export default function OmniBotReusable({ 
  provider, 
  initialMessage = "Hello! I'm your personal AI assistant. How can I help you today?",
  theme = { botName: "OmniBot AI" },
  tools
}: OmniBotProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [messages, setMessages] = useState<OmniBotMessage[]>([
    { role: 'model', text: initialMessage }
  ]);
  const [input, setInput] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [isScreenShared, setIsScreenShared] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  
  // Section Selection State
  const [isSelectingSection, setIsSelectingSection] = useState(false);
  const [frozenImageDataUrl, setFrozenImageDataUrl] = useState<string | null>(null);
  const [selectionStart, setSelectionStart] = useState<{x: number, y: number} | null>(null);
  const [selectionCurrent, setSelectionCurrent] = useState<{x: number, y: number} | null>(null);
  const [isPreparingSelection, setIsPreparingSelection] = useState(false);

  const dragControls = useDragControls();

  // Cancel selection on Escape
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isSelectingSection) {
        setIsSelectingSection(false);
        setSelectionStart(null);
        setSelectionCurrent(null);
        setFrozenImageDataUrl(null);
        setIsOpen(true);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isSelectingSection]);

  // Keyboard shortcut: Ctrl + D + H
  useEffect(() => {
    const keys: Record<string, boolean> = {};
    const handleCombo = (e: KeyboardEvent) => {
      keys[e.key.toLowerCase()] = e.type === 'keydown';
      if (keys['control'] && keys['d'] && keys['h']) {
        e.preventDefault();
        setIsOpen(prev => !prev);
      }
    };

    window.addEventListener('keydown', handleCombo);
    window.addEventListener('keyup', handleCombo);
    return () => {
      window.removeEventListener('keydown', handleCombo);
      window.removeEventListener('keyup', handleCombo);
    };
  }, []);

  // Auto-scroll to bottom when messages change
  useEffect(() => {
    if (scrollRef.current) {
      const scrollContainer = scrollRef.current.querySelector('[data-slot="scroll-area-viewport"]');
      if (scrollContainer) {
        scrollContainer.scrollTop = scrollContainer.scrollHeight;
      }
    }
  }, [messages, isProcessing]);

  useEffect(() => {
    return () => {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  const toggleScreenShare = async () => {
    if (isScreenShared) {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(track => track.stop());
        streamRef.current = null;
      }
      setIsScreenShared(false);
      setMessages(prev => [...prev, { role: 'model', text: "Screen sharing disconnected." }]);
    } else {
      try {
        const stream = await navigator.mediaDevices.getDisplayMedia({ video: true });
        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          await videoRef.current.play();
        }
        setIsScreenShared(true);
        setMessages(prev => [...prev, { role: 'model', text: "Screen connected! I can now see your screen. Ask me anything about it." }]);

        stream.getVideoTracks()[0].onended = () => {
          setIsScreenShared(false);
          streamRef.current = null;
          setMessages(prev => [...prev, { role: 'model', text: "Screen sharing was stopped." }]);
        };
      } catch (error: any) {
        console.error("Screen share error:", error);
        let errorMsg = "Failed to share screen.";
        if (error.name === 'NotAllowedError') {
          if (error.message?.toLowerCase().includes('denied')) {
            errorMsg = "Screen sharing was cancelled.";
          } else {
            errorMsg = "Screen capture is blocked by browser policy. **Please open the app in a new tab** to allow screen sharing.";
          }
        } else if (error.message?.includes('permissions policy')) {
          errorMsg = "Screen capture is blocked by browser policy. **Please open the app in a new tab** to allow screen sharing.";
        }
        setMessages(prev => [...prev, { role: 'model', text: `**Error:** ${errorMsg}` }]);
      }
    }
  };

  const handleSend = async () => {
    if (!input.trim() || isProcessing) return;
    
    const userMsg = input;
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setIsProcessing(true);

    try {
      let base64Image: string | undefined;
      let contextualPrompt = userMsg;

      if (isScreenShared && videoRef.current) {
        const canvas = document.createElement('canvas');
        canvas.width = videoRef.current.videoWidth;
        canvas.height = videoRef.current.videoHeight;
        const ctx = canvas.getContext('2d');
        ctx?.drawImage(videoRef.current, 0, 0);
        base64Image = canvas.toDataURL('image/png').split(',')[1];
      } else {
        // Fallback to DOM context if no screen shared
        const mainContent = document.querySelector('main')?.innerText || document.body.innerText;
        const cleanContent = mainContent.replace(/\n+/g, '\n').trim().substring(0, 3000);
        contextualPrompt = `[Hidden Screen Context - The user is currently looking at this data on the screen:\n${cleanContent}\n]\n\nUser Question: ${userMsg}`;
      }

      const response = await provider.chat(messages, contextualPrompt, tools, base64Image);
      setMessages(prev => [...prev, { role: 'model', text: response }]);
    } catch (error: any) {
      console.error("OmniBot Error:", error);
      setMessages(prev => [...prev, { role: 'model', text: `**Error:** ${error.message || "Failed to get response. Check your connection."}` }]);
    } finally {
      setIsProcessing(false);
    }
  };

  const startSectionAnalysis = async () => {
    setIsPreparingSelection(true);
    try {
      // Hide the bot temporarily so it doesn't get captured in the screenshot
      setIsOpen(false);
      // Wait a tiny bit for the bot UI to disappear
      await new Promise(resolve => setTimeout(resolve, 150));
      
      let dataUrl: string;

      // If screen is already shared, use the native video stream
      if (isScreenShared && videoRef.current) {
        const canvas = document.createElement('canvas');
        canvas.width = videoRef.current.videoWidth;
        canvas.height = videoRef.current.videoHeight;
        const ctx = canvas.getContext('2d');
        ctx?.drawImage(videoRef.current, 0, 0);
        dataUrl = canvas.toDataURL('image/png');
      } else {
        // Automatically capture the current webpage without prompting
        dataUrl = await htmlToImage.toPng(document.documentElement, {
          pixelRatio: 1, // Force 1 to avoid canvas size limits
          width: window.innerWidth,
          height: window.innerHeight,
          backgroundColor: window.getComputedStyle(document.body).backgroundColor || '#ffffff',
          fontEmbedCSS: '', // Skip font embedding to avoid network/CORS issues
          filter: (node: any) => {
            const tag = node?.tagName?.toLowerCase();
            // Filter out elements that can cause SVG rendering to fail (like external stylesheets or scripts)
            if (['script', 'noscript', 'style', 'link', 'meta', 'video', 'iframe'].includes(tag)) {
              return false;
            }
            return true;
          },
        });
      }
      
      setFrozenImageDataUrl(dataUrl);
      setIsSelectingSection(true);
    } catch (e: any) {
      console.error("Failed to prepare screen for selection", e);
      setIsOpen(true);
      setMessages(prev => [...prev, { 
        role: 'model', 
        text: `**Error:** Failed to capture the screen automatically. Details: ${e.message || 'SVG Rendering Error (External Resource Blocked)'}` 
      }]);
    } finally {
      setIsPreparingSelection(false);
    }
  };

  const handleSelectionMouseDown = (e: React.MouseEvent) => {
    setSelectionStart({ x: e.clientX, y: e.clientY });
    setSelectionCurrent({ x: e.clientX, y: e.clientY });
  };

  const handleSelectionMouseMove = (e: React.MouseEvent) => {
    if (selectionStart) {
      setSelectionCurrent({ x: e.clientX, y: e.clientY });
    }
  };

  const handleSelectionMouseUp = async () => {
    if (!selectionStart || !selectionCurrent || !frozenImageDataUrl) return;

    const x = Math.min(selectionStart.x, selectionCurrent.x);
    const y = Math.min(selectionStart.y, selectionCurrent.y);
    const width = Math.abs(selectionCurrent.x - selectionStart.x);
    const height = Math.abs(selectionCurrent.y - selectionStart.y);

    setIsSelectingSection(false);
    setSelectionStart(null);
    setSelectionCurrent(null);
    const currentDataUrl = frozenImageDataUrl;
    setFrozenImageDataUrl(null);
    setIsOpen(true); // Re-open bot

    if (width < 20 || height < 20) {
      // Too small, probably a click
      return;
    }

    setIsProcessing(true);
    setMessages(prev => [...prev, { role: 'user', text: '[Selected a region of the screen]' }]);

    try {
      const img = new Image();
      img.src = currentDataUrl;
      await new Promise(resolve => { img.onload = resolve; });

      // Calculate scale factor in case pixelRatio was used
      const scaleX = img.width / window.innerWidth;
      const scaleY = img.height / window.innerHeight;

      // Crop the frozen canvas
      const cropCanvas = document.createElement('canvas');
      cropCanvas.width = width * scaleX;
      cropCanvas.height = height * scaleY;
      const ctx = cropCanvas.getContext('2d');
      
      // Draw the cropped region
      ctx?.drawImage(
        img, 
        x * scaleX, y * scaleY, width * scaleX, height * scaleY, 
        0, 0, width * scaleX, height * scaleY
      );
      
      const base64Image = cropCanvas.toDataURL('image/png').split(',')[1];

      const response = await provider.chat(
        messages, 
        "I have selected this specific portion of my screen. Please analyze it, tell me what you see, and ask me what I want to know more about it.", 
        tools, 
        base64Image
      );
      setMessages(prev => [...prev, { role: 'model', text: response }]);
    } catch (error: any) {
      console.error("Analysis error:", error);
      setMessages(prev => [...prev, { role: 'model', text: `**Error:** Failed to analyze the selected section.` }]);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="fixed inset-0 pointer-events-none z-50 font-sans">
      <video ref={videoRef} className="hidden" playsInline muted />
      <AnimatePresence>
        {isOpen && (
          <motion.div
            drag
            dragControls={dragControls}
            dragListener={false}
            dragMomentum={false}
            initial={{ opacity: 0, scale: 0.8, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.8, y: 20 }}
            className="absolute bottom-24 right-8 w-96 pointer-events-auto"
          >
            <Card className="shadow-2xl border-primary/20 bg-background/95 backdrop-blur-xl overflow-hidden flex flex-col h-[600px] border-2">
              <div 
                className="p-4 border-b bg-primary text-primary-foreground flex justify-between items-center cursor-move shadow-sm shrink-0 active:cursor-grabbing"
                onPointerDown={(e) => dragControls.start(e)}
              >
                <div className="flex items-center gap-3 pointer-events-none">
                  <div className="p-1.5 bg-white/20 rounded-lg">
                    <Bot className="w-5 h-5" />
                  </div>
                  <div className="flex flex-col">
                    <span className="font-bold text-sm tracking-tight leading-none">{theme.botName}</span>
                    <span className="text-[10px] opacity-70">Always active</span>
                  </div>
                </div>
                <div className="flex items-center gap-1">
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="h-8 w-8 hover:bg-white/20 rounded-full"
                    onClick={() => setIsOpen(false)}
                    onPointerDown={(e) => e.stopPropagation()}
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              <ScrollArea className="flex-1 min-h-0" ref={scrollRef}>
                <div className="p-4 space-y-6 pb-12">
                  {messages.map((m, i) => (
                    <div key={i} className={cn(
                      "flex flex-col gap-1",
                      m.role === 'user' ? "items-end" : "items-start"
                    )}>
                      <div className={cn(
                        "max-w-[85%] p-3 rounded-2xl text-sm leading-relaxed shadow-sm transition-all duration-200",
                        m.role === 'user' 
                          ? "bg-primary text-primary-foreground rounded-tr-none" 
                          : m.text.startsWith("**Error:**") 
                            ? "bg-destructive/10 border-destructive/20 text-destructive rounded-tl-none border"
                            : "bg-muted rounded-tl-none border border-border/50"
                      )}>
                        <div className="prose prose-sm dark:prose-invert max-w-none break-words">
                          <ReactMarkdown>{m.text}</ReactMarkdown>
                        </div>
                      </div>
                      <span className="text-[10px] text-muted-foreground px-1 opacity-50">
                        {m.role === 'user' ? 'You' : theme.botName}
                      </span>
                    </div>
                  ))}
                  {isProcessing && (
                    <div className="flex flex-col items-start gap-1">
                      <div className="bg-muted p-4 rounded-2xl rounded-tl-none border border-border/50 flex gap-1.5">
                        <motion.div 
                          animate={{ scale: [1, 1.2, 1], opacity: [0.5, 1, 0.5] }}
                          transition={{ repeat: Infinity, duration: 1 }}
                          className="w-2 h-2 rounded-full bg-primary" 
                        />
                        <motion.div 
                          animate={{ scale: [1, 1.2, 1], opacity: [0.5, 1, 0.5] }}
                          transition={{ repeat: Infinity, duration: 1, delay: 0.2 }}
                          className="w-2 h-2 rounded-full bg-primary" 
                        />
                        <motion.div 
                          animate={{ scale: [1, 1.2, 1], opacity: [0.5, 1, 0.5] }}
                          transition={{ repeat: Infinity, duration: 1, delay: 0.4 }}
                          className="w-2 h-2 rounded-full bg-primary" 
                        />
                      </div>
                    </div>
                  )}
                </div>
              </ScrollArea>

                  <div className="p-4 border-t bg-muted/20 space-y-4 shrink-0">
                    <div className="flex gap-2">
                      <Button 
                        variant={isScreenShared ? "default" : "outline"}
                        size="sm" 
                        className={cn(
                          "flex-1 gap-2 text-xs h-9 rounded-xl transition-all",
                          isScreenShared ? "bg-green-600 hover:bg-green-700 text-white border-transparent" : "hover:bg-background"
                        )}
                        onClick={toggleScreenShare}
                        disabled={isProcessing || isPreparingSelection}
                      >
                        {isScreenShared ? <MonitorOff className="w-3.5 h-3.5" /> : <MonitorUp className="w-3.5 h-3.5" />}
                        {isScreenShared ? "Stop Sharing" : "Share Screen"}
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        className="flex-1 gap-2 text-xs h-9 rounded-xl transition-all hover:bg-background"
                        onClick={startSectionAnalysis}
                        disabled={isProcessing || isPreparingSelection}
                      >
                        {isPreparingSelection ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Crop className="w-3.5 h-3.5" />}
                        {isPreparingSelection ? "Preparing..." : "Analyze Section"}
                      </Button>
                    </div>
                    <div className="flex gap-2 relative">
                      <Input 
                        placeholder="Ask me anything..." 
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                        className="bg-background h-11 rounded-xl pr-12 border-2 focus-visible:ring-primary/20"
                        disabled={isProcessing}
                      />
                      <Button 
                        size="icon" 
                        onClick={handleSend} 
                        disabled={!input.trim() || isProcessing}
                        className="absolute right-1 top-1 h-9 w-9 rounded-lg"
                      >
                        <Send className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>

      <motion.button
        layout
        drag
        dragMomentum={false}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => setIsOpen(!isOpen)}
        className={cn(
          "fixed bottom-8 right-8 w-16 h-16 rounded-full shadow-2xl flex items-center justify-center pointer-events-auto transition-all z-50 border-4 border-background cursor-grab active:cursor-grabbing",
          isOpen ? "bg-destructive text-destructive-foreground rotate-90" : "bg-primary text-primary-foreground"
        )}
      >
        {isOpen ? <X className="w-7 h-7 pointer-events-none" /> : <Bot className="w-7 h-7 pointer-events-none" />}
      </motion.button>

      {/* Section Selection Overlay */}
      {isSelectingSection && frozenImageDataUrl && (
        <div 
          className="fixed inset-0 z-[99999] cursor-crosshair overflow-hidden pointer-events-auto"
          style={{
            backgroundImage: `url(${frozenImageDataUrl})`,
            backgroundSize: '100% 100%',
          }}
          onMouseDown={handleSelectionMouseDown}
          onMouseMove={handleSelectionMouseMove}
          onMouseUp={handleSelectionMouseUp}
        >
          {!selectionStart && (
            <div className="absolute inset-0 bg-black/40 pointer-events-none transition-opacity duration-300" />
          )}
          
          {selectionStart && selectionCurrent && (
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.15, ease: "easeOut" }}
              className="absolute border-2 border-primary bg-primary/10 pointer-events-none backdrop-brightness-110"
              style={{
                left: Math.min(selectionStart.x, selectionCurrent.x),
                top: Math.min(selectionStart.y, selectionCurrent.y),
                width: Math.abs(selectionCurrent.x - selectionStart.x),
                height: Math.abs(selectionCurrent.y - selectionStart.y),
                boxShadow: '0 0 0 9999px rgba(0,0,0,0.6)',
              }}
            >
               {/* Corner accents for better visual feedback */}
               <div className="absolute top-0 left-0 w-3 h-3 border-t-2 border-l-2 border-primary -translate-x-[2px] -translate-y-[2px]" />
               <div className="absolute top-0 right-0 w-3 h-3 border-t-2 border-r-2 border-primary translate-x-[2px] -translate-y-[2px]" />
               <div className="absolute bottom-0 left-0 w-3 h-3 border-b-2 border-l-2 border-primary -translate-x-[2px] translate-y-[2px]" />
               <div className="absolute bottom-0 right-0 w-3 h-3 border-b-2 border-r-2 border-primary translate-x-[2px] translate-y-[2px]" />
            </motion.div>
          )}
          
          <div className="absolute top-8 left-1/2 -translate-x-1/2 bg-background/95 backdrop-blur-md text-foreground px-6 py-3 rounded-full shadow-2xl pointer-events-none font-medium flex items-center gap-3 animate-in fade-in slide-in-from-top-4 border">
            <div className="p-1.5 bg-primary/10 text-primary rounded-md">
              <Crop className="w-4 h-4" />
            </div>
            Drag to select an area to analyze <span className="text-muted-foreground ml-2 text-sm font-normal">(Press Esc to cancel)</span>
          </div>
        </div>
      )}
    </div>
  );
}
