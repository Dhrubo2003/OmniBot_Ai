export interface OmniBotMessage {
  role: 'user' | 'model';
  text: string;
}

export interface OmniBotTool {
  name: string;
  description: string;
  parameters: any; // JSON Schema for arguments
  execute: (args: any) => Promise<any> | any;
}

export interface OmniBotProvider {
  /**
   * Send a message to the LLM and get a response.
   * @param history The conversation history.
   * @param message The new message from the user.
   * @param tools Optional list of tools the model can call.
   * @param base64Image Optional base64 image of the current screen context.
   */
  chat: (history: OmniBotMessage[], message: string, tools?: OmniBotTool[], base64Image?: string) => Promise<string>;

  /**
   * Analyze a screenshot with a prompt.
   * @param base64Image The screenshot as a base64 string (without prefix).
   * @param prompt The analysis prompt.
   */
  analyze: (base64Image: string, prompt: string) => Promise<string>;
}

export interface OmniBotProps {
  /**
   * The AI provider implementation (Gemini, GPT, Ollama, etc.)
   */
  provider: OmniBotProvider;
  
  /**
   * Optional initial message from the bot.
   */
  initialMessage?: string;

  /**
   * Optional theme configuration.
   */
  theme?: {
    primaryColor?: string;
    botName?: string;
  };

  /**
   * Optional list of tools the bot can use to interact with the app.
   */
  tools?: OmniBotTool[];
}
