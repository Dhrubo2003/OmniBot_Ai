/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useMemo, useState } from 'react';
import OmniBotReusable from "./components/OmniBotReusable";
import { OllamaProvider } from "./lib/providers";
import { OmniBotTool } from "./types/omnibot";

export default function App() {
  const [bgColor, setBgColor] = useState("#ffffff");

  // Example tool to show how to integrate with the host website
  const omniTools: OmniBotTool[] = [
    {
      name: "changeBackgroundColor",
      description: "Change the background color of the website.",
      parameters: {
        type: "OBJECT",
        properties: {
          color: { type: "STRING", description: "A valid CSS color (e.g., 'red', '#ff0000', 'lightblue')" }
        },
        required: ["color"]
      },
      execute: (args: any) => {
        setBgColor(args.color);
        return { success: true, message: `Background color changed to ${args.color}.` };
      }
    }
  ];

  // Initialize the Ollama provider (assuming Ollama is running locally on port 11434)
  // You can pass a different model name if needed, e.g., new OllamaProvider("http://localhost:11434", "llama3", "llava")
  const ollamaProvider = useMemo(() => new OllamaProvider(), []);

  return (
    <div 
      className="min-h-screen transition-colors duration-500 flex flex-col items-center justify-center p-8 text-foreground" 
      style={{ backgroundColor: bgColor }}
    >
      <div className="max-w-2xl text-center space-y-6 p-12 bg-background/80 backdrop-blur-md rounded-3xl border shadow-xl">
        <div className="w-16 h-16 bg-primary text-primary-foreground rounded-2xl flex items-center justify-center mx-auto shadow-lg mb-8">
          <span className="text-3xl font-bold">O</span>
        </div>
        <h1 className="text-5xl font-extrabold tracking-tight">Your Website Here</h1>
        <p className="text-xl text-muted-foreground leading-relaxed">
          This is a minimal integration example. The OmniBot widget is injected into this page.
        </p>
        <div className="p-6 bg-muted/50 rounded-xl border text-left space-y-2">
          <h3 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground">Try it out:</h3>
          <p className="text-sm">1. Open the bot using the floating button or <kbd className="px-2 py-1 bg-background border rounded text-xs">Ctrl+D+H</kbd></p>
          <p className="text-sm">2. Ask the bot: <i>"Change the background color to light blue"</i> to see function calling in action.</p>
          <p className="text-sm">3. Click <b>Share Screen</b> or <b>Analyze Section</b> to let the bot see what you see.</p>
          <p className="text-sm text-yellow-600 dark:text-yellow-400 mt-4">
            <b>Note:</b> Make sure Ollama is running locally with CORS enabled: <br/>
            <code className="bg-background px-2 py-1 rounded border">OLLAMA_ORIGINS="*" ollama serve</code>
          </p>
        </div>
      </div>

      {/* The OmniBot Component */}
      <OmniBotReusable 
        provider={ollamaProvider} 
        theme={{ botName: "OmniBot Assistant", primaryColor: "#000000" }}
        tools={omniTools}
      />
    </div>
  );
}
